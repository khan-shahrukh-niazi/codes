#include <iostream>
using namespace std;
class node
{
private:
    int data;
    node *next;
    node *prev;
public:

    node(int x)
    {
        data=x;
        next=NULL;
        prev=NULL;
    }
    void setdata(int x)
    {
        data=x;
    }
    int getdata()
    {
        return data;
    }
    void setnext(node *x)
    {
        next=x;
    }
    node* getnext()
    {
        return next;
    }
    void setprev(node *x)
    {
        prev=x;
    }
    node* getprev()
    {
        return prev;
    }
};
class linklist
{
public:
    node *first;
    linklist()
    {
        first=NULL;
    }
    void addatstart(int x)
    {
        node *new1=new node(x);

        if(first==NULL)
        {
            first=new1;
            new1->setprev(NULL);
            return;
        }
        new1->setnext(first);
        first->setprev(new1);
        first=new1;
        first->setprev(NULL);
    }
    void display()
    {
        int x=1;
        node *temp=first;
        while(temp!=NULL)
        {
            cout<<x<<"->"<<temp->getdata()<<endl;
            temp=temp->getnext();
            x++;
        }
    }
    void addatend(int x)
    {
        node *new1=new node(x);

        if(first==NULL)
        {
            first=new1;
            return;
        }
        node *temp=first;
        while(temp->getnext()!=NULL)
        {
            temp=temp->getnext();
        }

        temp->setnext(new1);
        new1->setprev(temp);
    }
    void removefromstart()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from start of list \n";
            return;
        }
        if(first->getnext()==NULL)
        {
            first=NULL;
            return;
        }
        first=first->getnext();
        first->setprev(NULL);
    }
    void removefromend()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from end of list \n";
            return;
        }
        if(first->getnext()==NULL)
        {
            first=NULL;
            return;
        }
        node *temp=first;
        while(temp->getnext()->getnext()!=NULL)
        {
            temp=temp->getnext();
        }
        temp->setnext(NULL);
    }
    void Remove(int value)
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not perform given task on list \n";
            return;
        }
        if(first->getdata()==value)
        {
            removefromstart();
            return;
        }
        node *temp=first;
        while(temp->getnext()!=NULL)
        {
            if(temp->getnext()->getdata()==value)
            {
                node *free=temp;
                temp->setnext(temp->getnext()->getnext());
                temp->setprev(free);
                break;
            }
            temp=temp->getnext();
            if(temp==NULL)
            {
                break;
            }
        }

    }
    int listlength()
    {
        int x=0;
        node *temp=first;
        while(temp!=NULL)
        {
            temp=temp->getnext();
            x++;
        }
        return x;
    }
    void removeAt(int index)
    {
        if(first==NULL)
        {
            cout<<" LIST is EMPTY \n";
            return;
        }
        if(index > listlength())
        {
            cout<<" given index ("<<index<<") is not present in list \n";
            display();
            return;
        }
        if(index==0)
        {
            cout<<"list start from 1 NOT 0 so reenter the index sir:\n";
            return;
        }

        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {

            if(index==1)
            {
                removefromstart();
                break;
            }
            y++;

            if(index==y)
            {

                node *free=temp;
                temp->setnext(temp->getnext()->getnext());
                temp->setprev(free);
                break;
            }
            temp=temp->getnext();

        }
    }
    void  addAt(int index,int value)
    {
        if(first==NULL)
        {
            cout<<"list is empty\n";
            return;
        }
        if(index==0 ||index==1)
        {
            addatstart(value);
            return;
        }
        if(index >listlength())
        {
            addatend(value);
            return;
        }
        node *temp=first;

        int y=1;
        while(temp!=NULL)
        {
            if(y==index-1)
            {
                node *new1=new node(value);
                new1->setnext(temp->getnext());
                temp->getnext()->setprev(new1);
                temp->setnext(new1);
                new1->setprev(temp);
                break;
            }

            temp=temp->getnext();
            y++;
        }
    }
    void sir(int value)
    {
        node *new1=new node(value);
        node *temp=first;
        while(temp!=NULL)
        {
            if(temp->getnext()->getdata()>= new1->getdata())
            {
                node *new1=new node(value);
                new1->setnext(temp->getnext());
                temp->getnext()->setprev(new1);
                temp->setnext(new1);
                new1->setprev(temp);
                break;
            }
            temp=temp->getnext();
        }
    }
    int getat(int index)
    {
        if(index==0)
        {
            index=1;
        }
        if(first==NULL)
        {
            return -1;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(index==y)
            {
                return temp->getdata();
            }
            temp=temp->getnext();
            y++;
        }
        return -1;
    }
    int Find(int value)
    {
        if(first==NULL)
        {
            cout<<"list is empty \n";
            return -1;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(temp->getdata()==value)
            {
                return y;
            }
            temp=temp->getnext();
            y++;
        }
        return -1;
    }
};
/*void menu()
{
    linklist s;
    int value,index;
    /*char choice;
    while(choice!='Q' && choice!='q')
    {
        cout<<"\t\t\t             -> DOUBLE LINK LIST <-                 \n";
        cout<<"\t\t\t___________________________________________________________________\n";
        cout<<"\t\t\t<> enter F or f to Finds the specified value and returns its index<>\n";
        cout<<"\t\t\t<> enter L or l to display  the length of list for you            <>\n";
        cout<<"\t\t\t<> enter M or m to Returns the value from given index             <>\n";
        cout<<"\t\t\t<> enter O or o to remove given value node from list              <>\n";
        cout<<"\t\t\t<> enter P or p to remove given index node from list              <>\n";
        cout<<"\t\t\t<> enter R or r to remove node from start of list                 <>\n";
        cout<<"\t\t\t<> enter W or w to add given value at given index                 <>\n";
        cout<<"\t\t\t<> enter Z or z to remove node from end of list                   <>\n";
        cout<<"\t\t\t<> enter E or e to add node at the end of list                    <>\n";
        cout<<"\t\t\t<> enter Q or q to quit(exit) the program                         <>\n";
        cout<<"\t\t\t<> enter A or a to add at start of list                           <>\n";
        cout<<"\t\t\t<> enter D or d to display list for you                           <>\n";
        cout<<"\t\t\t___________________________________________________________________\n";
        cin>>choice;
        if(choice=='A' || choice=='a')
        {
            cout<<"enter the value to add at start of list\n";
            cin>>value;

            s.addatstart(value);
        }
        if(choice=='D' || choice=='d')
        {
            cout<<" displaying list for you sir\n";
            s.display();
        }
        if(choice=='E' || choice=='e')
        {
            cout<<"enter the value to add node at the end of list\n";
            cin>>value;
            s.addatend(value);
        }
        if(choice=='R' || choice=='r')
        {
            cout<<"removing value from start of list\n";
            s.removefromstart();
        }
        if(choice=='Z' || choice=='z')
        {
            cout<<"removing value from start \n";
            s.removefromend();
        }
        if(choice=='O' || choice=='o')
        {
            cout<<"We are going to remove given value's node from list \n";
            cout<<"enter the value\n";
            cin>>value;
            s.Remove(value);
        }
        if(choice=='P' || choice=='p')
        {
            cout<<"we are going to remove given index from list\n";
            cout<<" give the index sir\n";
            cin>>index;
            s.removeAt(index);
        }
        if(choice=='W' || choice=='w')
        {
            cout<<"adding given value (by user) at given index by user \n";
            cout<<"give value=\n";
            cin>>value;
            cout<<"give index=\n";
            cin>>index;
            s.addAt(index,value);
        }
        if(choice=='M' || choice=='m')
        {
            cout<<" give index to give you value sir\n";
            cin>>index;
            int y=s.getat(index);
            if(y==-1)
            {
                cout<<"\n no index is present in list sorry <-OR-> list is empty \n";
            }
            else
            {
                cout<<"value present on given index("<<index<<") in list is "<<y<<endl;
            }


        }
        if(choice=='F'|| choice=='f')
        {
            cout<<" enter the value to check its index number in list\n";
            cin>>value;
            int x=s.Find(value);
            if(x==-1)
            {
                cout<<"\n value("<<value<<") is not present in list OR list is empty\n";
            }
            else
            {
                cout<<"\n value("<<value<<") is present  at "<<x<<" index\n";
            }

        }
        if(choice=='L' || choice=='l')
        {
            cout<<"list of length is "<< s.listlength()<<endl;
        }

    }
}*/
int main()
{
    //menu();
    linklist l;
    l.addatstart(1);
    l.addatend(2);
    l.addatend(4);
    l.sir(3);
    l.display();
    return 0;
}
