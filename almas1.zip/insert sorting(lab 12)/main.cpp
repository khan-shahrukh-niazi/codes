#include <iostream>
using namespace std;
class Sort
{
public:
    int c=0,n=0;
    void Sorting(int hello[],int x)
    {
        while(x>0)
        {
            if(hello[x] < hello[x-1])
            {
                int y=hello[x];
                hello[x]=hello[x-1];
                hello[x-1]=y;
            }
            x--;

        }

    }

    void Insersort(int hello[])
    {
        int c=0;
        for(int i=0; i<=4; i++)
        {
            Sorting(hello,c);
            c++;
        }
        for(int i=0; i<5; i++)
            cout<<i<<"-->"<<hello[i]<<endl;

    }

};
int main()
{
    Sort s;
    int hello[5]= {100,99,88,77,66};
    s.Insersort(hello);
    return 0;
}
