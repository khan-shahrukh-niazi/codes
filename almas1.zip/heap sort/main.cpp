#include<iostream>
using namespace std;
class Heap
{
public:
    int a=0,c=-1,p=0;
    int arrays[15]= {0};
    int Sort[15]= {0};
    void add(int value)
    {

        arrays[a]=value;
        if(arrays[a]>arrays[(a-1)/2])  //going to exchange elements to maintain Heap Sir
        {
            int x=a;
            int y;
            while(x!=0)
            {
                if(arrays[x]>arrays[(x-1)/2])
                {
                    y=arrays[(x-1)/2];
                    arrays[(x-1)/2]=value;
                    arrays[x]=y;
                }
                x=(x-1)/2;
            }
        }
        a++;
        c++;
    }
    void display()
    {
        for(int x=0; x<=14; x++)
            cout<<"\t\t\t\t"<<x<<"-->"<<arrays[x]<<endl;
    }
    void get_L_R_P(int x)
    {
        int p,r,l;
        p=(x-1)/2;
        l=2*x+1;
        r=2*x+2;
        if(arrays[l]==0 && arrays[r]==0)
        {
            cout<<"\t\t Right and Left are Empty index in heap till now";
            cout<<"\t\t parent is "<<arrays[p]<<endl;
            return;
        }
        if(arrays[l]>14 && arrays[r]>14)
        {
            cout<<"\t\t Right and Left are not present in heap now";
            cout<<"\t\t parent is "<<arrays[p]<<endl;
            return;
        }
        if(arrays[r]>14)
        {
            cout<<"\t\t Right is not present in heap";
            cout<<"\t\t parent is "<<arrays[p]<<endl;
            return;
        }
        cout<<"\t\t\t left is "<<arrays[l];
        cout<<"\t\t\t right is "<<arrays[r];
        cout<<"\t\t\t parent is "<<arrays[p]<<endl;

    }
    void getTOP()
    {
        cout<<"\n\t TOP of heap is "<<arrays[0]<<endl;
    }
    int Isheap(int hello[],int x)
    {

        for(int i=0; i<(x-1)/2; i++)
        {
            if(hello[2*i+1] > hello[i])
            {
                cout<<" OMG ->> its not heap \n";
                return 0;
            }
            if(hello[2*i+2] > hello[i])
            {
                cout<<" OMG ->> its not heap \n";
                return 0;
            }
            cout<<i<<endl;
        }
        cout<<"hey its heap\n";
        return 0;
    }
    void Delete()
    {
        int x=arrays[c];
        arrays[c]=arrays[0];
        Sort[p]=arrays[0];
        p++;
        arrays[c]=0;
        arrays[0]=x;
        int n=0;
        int y=0;
        if(c==0)
        {
            arrays[c]=0;
            return;
        }
        while(n<=(c-1)/2)
        {
            if(arrays[2*n+1] > arrays[2*n+2])
            {
                if(arrays[2*n+2]==0 && arrays[n] > arrays[2*n+1])
                    break;
                y=arrays[2*n+1];
                arrays[2*n+1]=arrays[n];
                arrays[n]=y;
                n=2*n+1;
            }
            else if(arrays[2*n+2] > arrays[2*n+1])
            {
                y=arrays[2*n+2];
                arrays[2*n+2]=arrays[n];
                arrays[n]=y;
                n=2*n+2;
            }
            else if(arrays[2*n+1]==arrays[2*n+2] && arrays[n] > arrays[2*n+1])
                break;
            else
            {
                y=arrays[2*n+1];
                arrays[2*n+1]=arrays[n];
                arrays[n]=y;
                n=2*n+1;
            }

        }

        a--;
        c--;


    }
    void show()
    {
           for(int x=0; x<=14; x++)
            cout<<x<<"-->"<<Sort[x]<<endl;
    }
};
void menu()
{
    Heap h;
    char c;
    int x;
    while(c!='e')
    {
        cout<<"\t\t\t\t >------------------------------<\n";
        cout<<"\t\t\t\t | press h to check heap or not | \n";
        cout<<"\t\t\t\t | press l to GET-L-P-R         |\n";
        cout<<"\t\t\t\t | press g to GET_TOP           |\n";
        cout<<"\t\t\t\t | press s to DISPLAY           |\n";
        cout<<"\t\t\t\t | press d to DELETE            |\n";
        cout<<"\t\t\t\t | press e to EXIT              |\n";
        cout<<"\t\t\t\t | press a to ADD               |\n";
        cout<<"\t\t\t\t >------------------------------<\n";
        cin>>c;
        if(c=='a')
        {
            cout<<"\n enter the value to add in heap\n";
            cin>>x;
            h.add(x);
        }
        if(c=='d')
        {
            cout<<"\n going to delete  element from heap sir\n";
            h.Delete();
        }
        if(c=='g')
        {
            cout<<"\n showing the top element of heap sir to you\n";
        }
        if(c=='l')
        {
            cout<<"\n enter the index to get left right and parent\n";
            cin>>x;
            cout<<"\n going to show LEFT RIGHT and PARENT of given index\n";
            h.get_L_R_P(x);
        }
        if(c=='h')
        {

            int y=0;
            cout<<"\n enter the length of the array you want to check is it heap or not\n";
            cin>>y;
        int hello[y]= {0};
            cout<<"\n enter the elements in array\n";
            for(int i=0; i<y; i++)
            {
                cin>>hello[i];
                cout<<endl;
            }
            h.Isheap(hello,y);
        }
        if(c=='s')
        {
            cout<<"\n going to display heap sir\n";
            h.display();
        }
    }
}
int main()
{
    cout<<"\t\t\t\t\t >-> WELCOME sir <-< \n\n";
    //menu();
Heap h;
    h.add(12);
    h.add(45);
    h.add(55);
    h.add(87);
    h.add(78);
    //h.Delete();
    h.Delete();
    h.Delete();
    h.Delete();
    h.Delete();
    h.show();
    h.display();
    return 0;
}
