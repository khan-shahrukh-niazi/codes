#include <iostream>

using namespace std;
int gcd (int a, int b)
{
    int i=1;
    int g=0;
    while(true){
        if(a%i==0 && b%i==0)
        {
            g=i;;
        }
        i++;
        if(i==a || i==b)
            break;
    }
    return g;
}
int mgcd(int a, int b)
{
    int reminder=a%b;
    while(true)
    {
        if (a==0 || b==0)
        {
            return 0;
        }
        reminder=a%b;
        if(reminder==0)   {return b ;}
        a=b;
        b=reminder;
    }
}
int rgcd(int a, int b){

if(a==0 || b==0)  { return 0;}
if(a%b==0) { return b;} else {rgcd(b,a%b); }

   }
   int square(int &x)
   {
   x*=x;      //x=x*x
   return x;
   }
   int squarepoint(int &x, int &y)
   {
       x*=x;
       y*=y;
       //return x;
   }
int main()
{
    //cout<<gcd(12,8);
    //cout<<mgcd(36,12);
    //cout<<rgcd(45,3);
    int x=3; int y=5;
    squarepoint(x,y);
    cout<<x<<" && "<< y<<endl;
    return 0;
}
