#include <iostream>
using namespace std;
void fib(int a,int b ,int c)
{if((a )<c)
{
    cout<<a<<endl;
    fib(b,a+b,c);
    cout<<"\n"<<a;

}
    return ;
}

int main()
{
        cout<<"enter no ";
    int a;
    cin>>a;
    cout << "\n\t\t\t\ fabonacci series\n"<<endl;
    fib(0,1,a);
    return 0;
}
