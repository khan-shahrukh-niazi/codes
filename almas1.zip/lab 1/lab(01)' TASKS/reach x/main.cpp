#include <iostream>
#include<fstream>
using namespace std;

int main()
{
    int i=0,j=0;
    ifstream file1;//to show or read the file
    file1.open("grid.txt");
    char c[9][9];
    for(int i=0;i<=8;i++)
    {

        for(int j=0;j<=7;j++)
        {
         file1>>c[i][j];
        if(c[0][0]!='A'){cout<<"wrong grid\n";break;}
        }
    }for(int i=1;i<=8;i++)
    {
        for(int j=0;j<=7;j++)
        {
         cout<<c[i][j];
        }
        cout<<endl;
    }
    for(int i=1;i<=8;i++)
    {
        for(int j=0;j<=7;j++)
        {
         if(c[i][j]=='1'){ /*cout<<"OMG 1 come in "<<i<<" row:: ";*/break;}
         if(c[i][j]=='X'){cout<<"x is reachable in "<<i<<" row";break;}
        }
    }
    for(int i=7;i<=0;i--)
    {
        for(int j=1;j<=8;j++)
        {
         if(c[j][i]=='1'){ /*cout<<"OMG 1 come in "<<i<<" row:: ";*/break;}
         if(c[j][i]=='X'){cout<<"x is reachable in "<<i<<" row";break;}
        }
    }

    return 0;
}
