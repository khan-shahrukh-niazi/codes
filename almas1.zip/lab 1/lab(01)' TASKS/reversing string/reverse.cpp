#include <iostream>

using namespace std;

int main()
{
    int sum=0;
    char strings[25],*pointer;
    cout<<"enter the string"<<endl;
    cin>>strings;
    pointer=strings;
    for(int i=0;*(pointer+i)!='\0';i++)
    {
     sum++;
    }
    int x=sum-1;
    cout<<"AFTER REVERSING GIVEN STRING\n";
    for( int i=x;i>=0;i--)
    {
        cout<<*(pointer+i);
    }
}
