#include <iostream>
#include<fstream>
using namespace std;

int main()
{
    int i=0,j=0,counter=0;
    ifstream file1;//to show or read the file
    file1.open("grid.txt");
    char c[18][8];
    for(int i=0;i<=17;i++)
    {
        for(int j=0;j<=7;j++)
        {
         file1>>c[i][j];
        }
    }
    for(int i=10;i<=17;i++)
    {
        if(c[9][0]!='B'){cout<<"wrong grid\n";break;}
        for(int j=0;j<=7;j++)
        {
         cout<<c[i][j];
        }
        cout<<endl;
    }
    cout<<endl;
     for(int i=10;i<=17;i++)
     {
         for(int x=0;x<=7;x++)
         {
             if(c[i][x]=='a' && x<6)
             {
                if(c[i][x+1]=='l'&& x<7 )
                    {
                        if(c[i][x+2]=='i' && x<7)
                        {counter++;}
             }
         }
     }
     }
     cout<<"\t\t\t\t ALI COMES "<<counter<<" times";
    return 0;

}

