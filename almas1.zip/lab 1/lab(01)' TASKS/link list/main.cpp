#include <iostream>
using namespace std;
class node{
public:
    int data;
    node *next;
node (int d)
{
    data=d;
    next=NULL;
}
};
class linklist{
    public:
node *first;
linklist()
{
    first=NULL;
}
void display()
{
    node *temp=first;
    while(temp!=NULL)
    {
        cout<<temp->data<<endl;
        temp=temp->next;
    }
}
void addatstart(int x)
{
    node *temp=new node(x);
    node *temp2=first;
    first=temp;
    first->next=temp2;
}
void addatend(int d)
{
    node *p=new node(d);
    node *temp=first;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=p;
    p->next=NULL;
}
};

int main()
{
    linklist s;
    s.addatstart(10);
    s.addatstart(20);
    s.addatstart(30);
    s.addatstart(40);
    s.addatstart(50);
    s.addatstart(60);
    s.addatend(100);
    s.addatend(200);
    s.addatend(300);
    s.addatend(400);
    s.addatend(500);
    s.addatend(600);
    s.display();
    return 0;
}
