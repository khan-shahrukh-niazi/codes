#include <iostream>
#include<fstream>
using namespace std;

int main()
{
    int i=0,j=0;
    ifstream file1;//to show or read the file
    file1.open("grid.txt");
    char c[9][9];
    for(int i=0;i<=8;i++)
    {

        for(int j=0;j<=7;j++)
        {
         file1>>c[i][j];
        if(c[0][0]!='A'){cout<<"wrong grid\n";break;}
        }
    }
    for(int i=0;i<=8;i++)
    {
        for(int j=0;j<=7;j++)
        {
            if(c[i][j]=='X'|| c[i][j]=='x ')
         cout<<"the row is ("<<i<<") && column is ("<<j+1<<")"<<" ignoring A line";
        }
    }
    if(c[0][0]=='A')
    {
    cout<<endl;
    for(int i=1;i<=8;i++)
    {
        for(int j=0;j<=7;j++)
        {
         cout<<c[i][j];
        }
        cout<<endl;
    }
    cout<<endl;
    }
    return 0;
}
