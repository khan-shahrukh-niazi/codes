#include <iostream>

using namespace std;

int main()
{
    int sum=0;
    char strings[25],*pointer;
    cout<<"enter the string"<<endl;
    cin>>strings;
    pointer=strings;
    for(int i=0;*(pointer+i)!='\0';i++)
    {
     sum++;
    }
    cout<<"\nLENGTH OF STRING="<<sum;
}
