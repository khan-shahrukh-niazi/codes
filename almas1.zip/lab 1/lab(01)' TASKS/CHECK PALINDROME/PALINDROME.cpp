#include <iostream>
using namespace std;
int main()
{
    char check[15];
    cout << "enter the world" << endl;
    cin>>check;

    int counter=0,sum=0,y=0;
    for(int i=0;check[i]!=0;i++)
    {
        counter++;
    }
    int x=counter-1;
    cout<<"\nconvert upper case letter in lower case by adding 32 to ASCII value of upper case letter\n\n";
    for(int i=0;i<=x;i++)
    {
        if(check[i]>=65 && check[i]<=92){check[i]=check[i]=check[i]+32;}
    }
    char again[counter];
    for(int i=x;i>=0;i--)
    {
         again[y]=check[i];
        y++;
    }
    again[x+1]='\0';
    for(int i=0; i<=x;i++)
    {
        if(check[i]==again[i])
        {
            sum++;
        }
    }
    if (sum==counter)
    {
        cout<<"GIVEN WORD ("<<check<<") IS PALINDROME WORD"<<endl;
    }
    else
        {
        cout<<"SORRY IT IS NOT PALINDROME WORD"<<endl;
        }
   return 0;
}
