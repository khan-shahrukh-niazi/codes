#include <iostream>

using namespace std;

int main()
{
  int num[3][4]={{1,2,3,4},{5,6,7,8},{8,7,6,5}};  //cout << "Hello world!" << endl;
  int rows=3,col=4;
  int *p=&num[0][0];
//  for(int i=0;i<rows;i++)
  //zz{
  //    for(int j=0;j<col;j++)
      //{
          cout<<*(p+2*4+3)<<" ";
      //}
      cout<<endl;
  //}
    return 0;
}
