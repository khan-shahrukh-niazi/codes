#include <iostream>
#include<fstream>
#include <string>
using namespace std;

int main()
{

    int i=0;char all[666]; int x=0;
    ifstream file1;//to show or read the file
    file1.open("main.cpp");
    while(!file1.eof())
    {
    file1>>all[i];
    i++;
    }
    cout<<"total length of code ="<<i;
    for( int j=0;j<=i;j++)
    {
        if(all[j]=='s')
        {
            if(all[j+1]=='t')
            {
                if(all[j+2]=='r')
                {
                    if(all[j+3]=='e')
                    {
                        if(all[j+4]=='a')
                        {
                            if(all[j+5]=='m')
                            {
                                x++;
                            }
                        }
                    }
                }
            }
        }
    }
    cout<<endl<<"stream comes "<<x<<" times";

    return 0;
}

