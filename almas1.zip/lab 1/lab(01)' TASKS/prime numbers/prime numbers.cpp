#include <iostream>
using namespace std;
void primechecker(int x);
int main()
{
    int number,counter=0,steps=0;
    cout<<"enter the number"<<endl;
    cin>>number;
    cout<<endl<<endl;
    cout<<"prime numbers according to requirement"<<endl<<endl;
    cout<<"2\n";
    for(int x=3;x<number;x=x+2)
    {

       primechecker(x);
           steps++;
           }
cout<<endl<<"steps are "<<steps;

    return 0;
}
         void primechecker(int x)
    {
    int counter=0;
    int i=1;
    while(x>=i)
     {
        if(x%i==0)
         {
            counter++;
         }
        i++;
     }
        if(counter==2){cout<<x<<endl;}
   }
