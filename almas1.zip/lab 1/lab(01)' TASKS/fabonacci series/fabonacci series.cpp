#include <iostream>

using namespace std;

int main()
{
    int number;
    int x=0,y=1,z;
    cout << "enter the number" << endl;
    cin>>number;

    int lists[55];
    int i=0;
    while(number>x)
    {
        lists[i]=x;
        z=x+y;
        x=y;
        y=z;
        i++;
    }
   cout<<":FABONACCI SERIES IN --> DIRECTION"<<endl;
   for(int j=0;j<i;j++){cout<<lists[j];cout<<" ";}
   cout<<endl;
   cout<<":FABONACCI SERIES IN <-- DIRECTION"<<endl;
   for(int j=i-1;j>=0;j--){cout<<lists[j];cout<<" " ;}

}
