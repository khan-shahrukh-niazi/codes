#include <iostream>

using namespace std;

void swaper(int &x,int &y)
{
    int a;
    a=x;
    x=y;
    y=a;
}
int main()
{
    int x,y;
    cout<<"enter the (x) number"<<endl;
    cin>>x;
    cout<<"enter the (y) number"<<endl;
    cin>>y;
    cout<<"before swapping  x="<<x<<" && y="<<y<<endl;
    swaper(x,y);
    cout<<"after swapping  x="<<x<<" && y="<<y<<endl;
    return 0;
}

