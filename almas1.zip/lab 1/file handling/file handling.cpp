#include <iostream>
#include<fstream>
using namespace std;

int main()
{
    ofstream file; //input data on file
    file.open("input.txt");
    file<<"12345678";
    file.close();
    int i=0,j=0;
    ifstream file1;//to show or read the file
    file1.open("input.txt");
    char c[1][8];
    while(file1.eof()==0)
    {
    file1>>c[i][j];
    j++;
    }
    for(int i=0;i<=7;i++)
    {
    cout<<c[0][i];
    }
}
