#include <iostream>
#include<fstream>
#include <string>
using namespace std;

int main()
{
    int j=0;char all[120];int c=0;
    ifstream file1;//to show or read the file
    file1.open("main.cpp");
    while(!file1.eof())
    {
    string c;
    getline(file1,c);

    size_t found =c.find("stream");
    if (found != string::npos)
    j++;
      }
    cout<<j<<endl;

    return 0;
}
