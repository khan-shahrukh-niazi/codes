#include <iostream>
using namespace std;
class node
{
private:
    int data;
    node *next;
public:

    node(int x)
    {
        data=x;
        next=NULL;
    }
    void setdata(int x)
    {
        data=x;
    }
    int getdata()
    {
        return data;
    }
    void setnext(node *x)
    {
        next=x;
    }
    node* getnext()
    {
        return next;
    }
};
class linklist
{
public:
    node *first;
    linklist()
    {
        first=NULL;
    }
    void rvs(node *n)
    {
        if(n==NULL)
        {
            return;
        }
        else
        {
            rvs(n->getnext());
            cout<<n->getdata()<<endl;
        }
    }
    void addatstart(int x)
    {
        node *temp=new node(x);
        node *tem=first;
        first=temp;
        first->setnext(tem);
    }
    void display()
    {
        int x=1;
        node *temp=first;
        while(temp!=NULL)
        {
            cout<<x<<"->"<<temp->getdata()<<endl;
            temp=temp->getnext();
            x++;
        }
    }

    void addatend(int x)
    {
        if(first==NULL)
        {
            node *new1=new node(x);
            first=new1;
            return;
        }

        node *temp1=new node(x);
        node *temp=first;
        while(temp->getnext()!=NULL)
        {
            temp=temp->getnext();
        }

        temp->setnext(temp1);
    }
    void addAt(int x,int index)
    {
        node *new1=new node(x);

        if(index<=0 )
        {
            index=1;
        }
        if(first==NULL || index==1)
        {
            addatstart(x);
            return;
        }
        if(index >listlength())
        {
            addatend(x);
            return;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(y==index-1)
            {
                new1->setnext(temp->getnext());
                temp->setnext(new1);
                break;
            }
            temp=temp->getnext();
            y++;
        }
    }
    void removefromstart()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from start of list \n";
            return;
        }
        first=first->getnext();
    }
    void removefromend()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from end of list \n";
            return;
        }
        if(first->getnext()==NULL)
        {
            first=NULL;
            return;
        }

        node *temp=first;
        while(temp->getnext()->getnext()!=NULL)
        {
            temp=temp->getnext();
        }
        temp->setnext(NULL);

    }
    void Remove(int value)
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not perform given task on list \n";
            return;
        }
        if(first->getdata()==value)
        {
            removefromstart();
            return;
        }
        node *temp=first;
        while(temp->getnext()!=NULL)
        {
            if(temp->getnext()->getdata()==value)
            {
                temp->setnext(temp->getnext()->getnext());
                break;
            }
            temp=temp->getnext();
            if(temp==NULL)
                break;
        }

    }
    void revers()
    {
        rvs(first);

    }
    int listlength()
    {
        int x=0;
        node *temp=first;
        while(temp!=NULL)
        {
            temp=temp->getnext();
            x++;
        }
        return x;
    }
    void removeAt(int index)
    {
        if(first==NULL)
        {
            cout<<" LIST is EMPTY \n";
            return;
        }
        if(index > listlength())
        {
            cout<<" given index ("<<index<<") is not present in list \n";
            display();
            return;
        }
        if(index==0)
        {
            cout<<"list start from 1 NOT 0 so reenter the index sir:\n";
            return;
        }

        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {

            if(index==1)
            {
                removefromstart();
                break;
            }
            y++;

            if(index==y)
            {

                temp->setnext(temp->getnext()->getnext());
                break;
            }
            temp=temp->getnext();


        }


    }
    void sortlist(char word)
    {
        if(first==NULL)
        {
            cout<<"list is empty sir \n";
            return;
        }
        node *i,*j;
        int x;
        if(word=='A' || word=='a')
        {
            for(i=first; i->getnext()!=NULL; i=i->getnext())
            {
                for(j=i->getnext(); j!=NULL; j=j->getnext())
                {
                    if(i->getdata() > j->getdata())
                    {
                        x=i->getdata();
                        i->setdata(j->getdata());
                        j->setdata(x);
                    }
                }
            }
        }
        if(word=='D' || word=='d')
        {
            for(i=first; i->getnext()!=NULL; i=i->getnext())
            {
                for(j=i->getnext(); j!=NULL; j=j->getnext())
                {
                    if(i->getdata() < j->getdata())
                    {
                        x=i->getdata();
                        i->setdata(j->getdata());
                        j->setdata(x);
                    }
                }
            }
        }

        display();
    }
    int getat(int index)
    {
        if(index==0)
        {
            index=1;
        }
        if(first==NULL)
        {
            return -1;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(index==y)
            {
                return temp->getdata();
            }
            temp=temp->getnext();
            y++;
        }
        return -1;
    }
    int Find(int value)
    {
        if(first==NULL)
        {
            cout<<"list is empty \n";
            return -1;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(temp->getdata()==value)
            {
                return y;
            }
            temp=temp->getnext();
            y++;
        }
        return -1;
    }
    void Middle()
    {
        node *fast=first;
        node *slow=first;
        if(first!=NULL)
        {
        while(fast->getnext()!=NULL)
        {
            fast=fast->getnext();
            fast=fast->getnext();
            if(fast==NULL)
                break;
            slow=slow->getnext();
            x++;

        }
        cout<<"middle value is "<<slow->getdata()<<endl;
        }
        else
        {
            cout<<"list is empty sir\n";
        }
    }
};
void menu()
{
    linklist s;
    char choice;
    int value=0,index=0;
    while(choice!='Z' &&  choice!='z')
    {
        cout<<"\t\t\t >-SHAHRUKH-KHAN------------------------------------CS-2nd--YEAR-<\n";
        cout<<"\t\t\t |Press F or f to Finds the specified value and returns its index|\n";
        cout<<"\t\t\t |Press W or w to add given value at given index in list         |\n";
        cout<<"\t\t\t |Press M or m to Returns the value from given index             |\n";
        cout<<"\t\t\t |Press O or o to Returns the middle value from list             |\n";
        cout<<"\t\t\t |Press V or v to remove given value node from list              |\n";
        cout<<"\t\t\t |Press T or t to remove the node of given index                 |\n";
        cout<<"\t\t\t |Press R or r to remove node from start of list                 |\n";
        cout<<"\t\t\t |Press P or p to display list in reverse order                  |\n";
        cout<<"\t\t\t |Press X or x to remove node from end of list                   |\n";
        cout<<"\t\t\t |press S or s to sort the  list in any order                    |\n";
        cout<<"\t\t\t |press L or l to show the length of list                        |\n";
        cout<<"\t\t\t |Press A or a to add at start of list                           |\n";
        cout<<"\t\t\t |Press E or e to add at end of list                             |\n";
        cout<<"\t\t\t |Press D or d to display list                                   |\n";
        cout<<"\t\t\t |Press Z or z to exist                                          |\n";
        cout<<"\t\t\t >---------------------SINGLE-LINK-LIST--------------------------<\n";

        cin>>choice;
        if(choice=='A' || choice=='a')
        {
            cout<<"give the value to add at start of list \n";
            cin>>value;
            s.addatstart(value);
        }
        if(choice=='D' || choice=='d')
        {
            cout<<"\n displaying list for you \n\n";
            s.display();
        }
        if(choice=='O' || choice=='o')
        {
            cout<<"\n displaying middle value of list for you \n\n";
            s.Middle();
        }
        if(choice=='E'|| choice=='e')
        {
            cout<<"give the value to add at end of list \n";
            cin>>value;
            s.addatend(value);
        }
        if(choice=='R' || choice=='r')
        {
            cout<<" removing value from the start of list \n";
            s.removefromstart();
        }
        if(choice=='X' || choice=='x')
        {
            cout<<" removing value from the end of list \n";
            s.removefromend();
        }
        if(choice=='L' || choice=='l')
        {
            cout<<" length of list is "<<s.listlength()<<"\n";
        }
        if(choice=='W' || choice=='w')
        {
            cout<<"adding given value (by user) at given index by user \n";
            cout<<"give value=\n";
            cin>>value;
            cout<<"give index=\n";
            cin>>index;
            s.addAt(value,index);
        }
        if(choice=='T' || choice=='t')
        {
            cout<<" give index to delete from list\n";
            cin>>index;
            s.removeAt(index);
        }
        if(choice=='V' || choice=='v')
        {
            cout<<"give the value to delete node of given value from list \n";
            cin>>value;
            s.Remove(value);
        }
        if(choice=='M' || choice=='m')
        {
            cout<<" give index to give you value sir\n";
            cin>>index;
            int y=s.getat(index);
            if(y==-1)
            {
                cout<<"\n no index is present in list sorry <-OR-> list is empty \n";
            }
            else
            {
                cout<<"value present on given index("<<index<<") in list is "<<y<<endl;
            }


        }
        if(choice=='F'|| choice=='f')
        {
            cout<<" enter the value to check its index number in list\n";
            cin>>value;
            int x=s.Find(value);
            if(x==-1)
            {
                cout<<"\n value("<<value<<") is not present in list OR list is empty\n";
            }
            else
            {
                cout<<"\n value("<<value<<") is present  at "<<x<<" index\n";
            }

        }

        if(choice=='S' || choice=='s')
        {
            char c;
            cout<<" list in sorted order\n";
            cout<<" enter (a or A) for ascending order OR enter (d or D) for descending order \n";
            cin>>c;
            s.sortlist(c);
        }
        if(choice=='P' || choice=='p')
        {
            cout<<"display list in reverse order\n";
            s.revers();
        }
    }
}
int main()
{
    menu();
    cout<<"\n\t\t\t Thanks Sir See You Again \n\n ";
    return 0;
}
