#include <iostream>

using namespace std;

class Hash
{
public:
    int hello[11]= {0};
    int k,z,j=0;
    int counter=0;
    int add (int key)
    {
        if(counter==11)
        {
            cout<<"hash table is full sir\n";
            return 0;
        }
        int x=Hashfunction(key);

        if(hello[x]==0)
        {
            hello[x]=key;
            counter++;
        }
        else
        {
            k=(x+j)%11;

            j++;
            while(hello[k]!=0 && hello[k]!=-1)
            {

                k=(x+j)%11;
                j++;
            }
            hello[k]=key;
            j=0;
            counter++;
        }

    }
    int Hashfunction(int key)
    {
        return key%11;
    }

    int Delete(int key)
    {
        int x=Hashfunction(key);
        int j;
        if(hello[x]==0)
            cout<<"This value is not present here"<<endl;
        if(hello[x]==-1)
            x++;
        if(hello[x]==key)
        {
            hello[x]=-1;
            counter--;
        }
        else
        {

            j=1;
            while(hello[x]!=0 && j<11)
            {
                x=(Hashfunction(key)+j)%11;
                if(hello[x]==key)
                {
                    hello[x]=-1;

                    counter--;
                    return 0;
                }
                j++;
            }

        }
    }
    int Search(int key)
    {
        int x=Hashfunction(key);
        int j;
        if(hello[x]==key)
        {
            cout<<"given data is present in hash table at "<<x<<" index "<<endl;
           return 0;
        }
        if(hello[x]==0 || hello[x]==-1)
         {
            cout<<"Given data is not present in hash table"<<endl;
        return 0;
         }
        if(hello[x]!=0)
        {
            j=1;
            while(hello[x]!=0 && j<11)
            {
                x=(Hashfunction(key)+j)%11;
                if(hello[x]==0)
                {
                    cout<<"No data is present here"<<endl;
                    return 0;
                }
                if(hello[x]==key)
{
                cout<<"given data is present in hash table at "<<x<<" index"<<endl;
                return 0;

 }               j++;
            }

        }
        cout<<"No present sir\n";

    }

    void display()
    {
        for(int i=0; i<=10; i++)
        {
            cout<<i<<"-->"<<hello[i]<<endl;
        }
    }

};


int main()
{
    Hash h;
    h.add(22);
    h.add(12);
    h.add(32);
    h.add(11);
    h.add(10);
    h.add(42);
    h.add(99);
    h.add(73);
    h.add(432);
    h.add(66);
    h.add(118);
//    h.Search(118);
   // h.Delete(22);
  //  h.Search(66);
  //  h.add(66);
    h.Search(667);
    h.display();
    return 0;
}
