#include <iostream>

using namespace std;
class QUICK
{
public:
    int DIVIDE(int hello[],int first,int last)
    {
        int pivot=hello[first];
        int x=1;
        for(int y=1; y<=last; y++)
        {
            if(hello[y]<=pivot)
            {
                int z=hello[y];
                hello[y]=hello[x];
                hello[x]=z;
                x++;
            }
        }
        int z=hello[first];
        hello[first]=hello[x-1];
        hello[x-1]=z;
        return x-1;
    }
    void Quicksort(int hello[],int first, int last)
    {
        if(first<last)
        {
            int pivot=DIVIDE(hello,first,last);
            Quicksort(hello,first,pivot-1);
            Quicksort(hello,pivot+1,last);
        }
    }
    void disply(int hello[])
    {
        cout<<endl<<endl;
        for(int i=0; i<16; i++)
        {
            cout<<hello[i]<<"  ";
        }
        cout<<endl<<endl;
    }
};
int main()
{
    QUICK q;
    int hello[16]= {503,87,512,61,908,170,897,275,653,426,154,509,612,677,765,703};
    q.Quicksort(hello,0,15);
    q.disply(hello);
    return 0;
}
