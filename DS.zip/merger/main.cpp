  #include<iostream>
  using namespace std;
  class Mer{
  public:
    void Mergesort(int left[],int right[],int hello[],int n)
    {
        int n1=n/2;
        int n2=n-n1;
        int i=0,j=0,k=0;
        while(i<n1 && j<n2)
        {
            if(left[i]<=right[j])
            {
               hello[k]=left[i];
                i++;

            }
            else if(left[i]>right[j])
            {
               hello[k]=right[j];
                j++;
            }
            k++;

        }
        while(i<n1)
        {
           hello[k]=left[i];
            i++;
            k++;
        }
        while(j<n2)
        {
           hello[k]=right[j];
            j++;
            k++;
        }
    }

    void merger(int hello[],int x)
    {
        if(x<2)
            return;
        int mid=x/2;
        int left[mid],right[x-mid];
        for(int i=0; i<mid; i++)
        {
            left[i]=hello[i];
        }
        for(int i=mid; i<x; i++)
        {
            right[i-mid]=hello[i];
        }
        merger(left,mid);
        merger(right,x-mid);
        Mergesort(left,right,hello,x);
    }
  };
  int main()
  {
      int hello[10]={516,12,14,16,11,2,87,90,56,100};
      Mer m;
      m.merger(hello,10);
      for (int i=0;i<10;i++)
        cout<<i<<"=="<<hello[i]<<endl;
  }
