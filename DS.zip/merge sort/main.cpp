#include <iostream>
using namespace std;
class Merge{
public:

int h1[5]={112,113,115,117,119};
int h2[5]={21,51,71,91,111};
int h3[10]={0};
void merger()
{

int l=5,r=5;
int i=0,j=0,k=0;
while(i<l && j<r)
{
    if(h1[i] > h2[j])
    {
        h3[k]=h2[j];
        j++;
    }
    else if(h1[i] < h2[j])
    {
        h3[k]=h1[i];
        i++;
    }
    k++;
}
while(i<l)
{
    h3[k]=h1[i];
    i++;
    k++;

}
while(j<r)
{
    h3[k]=h2[j];
    j++;
    k++;

}
}
 void display()
 {
     for(int i=0;i<10;i++)
        cout<<h3[i]<<endl;
 }
};
int main()
{
    Merge m;
    m.merger();
    m.display();
    return 0;
}
