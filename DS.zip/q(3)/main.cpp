#include <iostream>
#include<time.h>
#include<stdlib.h>
using namespace std;
class Quick
{
public:
    int DIVIDE(int hello[],int first,int last)
    {
        int pivot=hello[first];
        int x=1;
        for(int y=1; y<=last; y++)
        {
            if(hello[y]<=pivot)
            {
                int z=hello[y];
                hello[y]=hello[x];
                hello[x]=z;
                x++;
            }
        }
        int z=hello[first];
        hello[first]=hello[x-1];
        hello[x-1]=z;
        return x-1;
    }
    void quickSort(int hello[], int first, int last)
    {
        if (first < last)
        {
            srand(time(NULL));
            int r=first+rand()%(last-first);
            int z=hello[r];
            hello[r]=hello[first];
            hello[first]=z;

            int pivot = DIVIDE(hello, first, last);
            quickSort(hello, first, pivot - 1);
            quickSort(hello, pivot + 1, last);
        }
    }
    void disply(int hello[])
    {
        cout<<endl<<endl;
        for(int i=0; i<16; i++)
        {
            cout<<hello[i]<<"  ";
        }
        cout<<endl<<endl;
    }
};
int main()
{
    Quick q;
    int hello[16]= {503,87,512,61,908,170,897,275,653,426,154,509,612,677,765,703};
    q.quickSort(hello,0,15);
    q.disply(hello);
    return 0;
}
