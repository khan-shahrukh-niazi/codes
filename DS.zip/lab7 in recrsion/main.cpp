#include <iostream>
using namespace std;

class node
{
public:
    int data;
    node *left,*right;
    node(int x)
    {
        data=x;
        left=NULL;
        right=NULL;
    }
};
class tree
{
public:
    node *root;
    tree()
    {
        root=NULL;
    }
     void add(node* start,int d)
    {
        node *new1=new node(d);
         if(start->data>=d)
           {
            if(start->left!=NULL)
            add(start->left,d);
            else
               start->left=new1;
            }
        else if(start->data<d)
           {
                if(start->right!=NULL)
                add(start->right,d);
                else
                    start->right=new1;
            }
    }
    void add(int d)
    {
        if(root==NULL)
        {
            root=new node(d);
        }
       else
            add(root,d);
    }


    int sar( node* start, int value)
    {
        if (start == NULL )
        {
            cout<<"given data is not present in tree";
            return  0;
        }
        else if (start->data < value)
        {
            return sar(start->right, value);
        }
        else if(start->data >value)
        {

            return sar(start->left, value);
        }
        else
        {
            cout<<"data is present in tree\n";
            return 0;
        }
    }
    void inorder( node *root)
    {
        if (root != NULL)
        {
            inorder(root->left);
            cout<< root->data<<endl;
            inorder(root->right);
        }
    }
    void preorder(node *start)
    {
        if(start!=NULL)
            {
        cout<<start->data<<endl;
        preorder(start->left);
        preorder(start->right);
            }
    }
      void postorder(node *start)
    {
        if(start!=NULL)
            {
        postorder(start->left);
        postorder(start->right);
        cout<<start->data<<endl;
    }
    }
  node* low(node* start)
    {
        while(start->left != NULL)
            start=start->left;
        return start;
    }
    node*  deletes(  node *start,int value)
    {
        if(start==NULL)
            return start;
        else if(value <  start->data)
            start->left=deletes(start->left,value);
        else if(value  > start->data)
            start->right=deletes(start->right,value);
        else
        {
          if(start->left==NULL && start->right==NULL)
            {
                start=NULL;
                return start;
            }
            else if(start->left==NULL)
            {
                start=start->right;
                return start;
            }
            else if(start->right==NULL)
            {
                start=start->left;
                return start;
            }
            else
            {
                node *hello=low(start->right);
                start->data=hello->data;
                start->right=deletes(start->right,hello->data);
            }
        }
    }
       void rem(int value)
    {
        deletes(root,value);
    }

    void display()
    {
        cout<<"\n INORDER\n\n";
        inorder(root);
        cout<<"\n PREORDER\n\n";
        preorder(root);
            cout<<"\n POSTORDER\n\n";
        postorder(root);
    }
    void sarch(int value)
    {
        sar(root,value);
    }
};
int main()
{
    tree  t;
    t.add(100);
    t.add(100);
    t.add(150);
   t.add(200);
   t.add(110);
   t.add(25);
   t.add(75);
   t.add(9);
   t.add(11);
   t.add(7);
   t.rem(100);
   t.display();
   t.sarch(200);

}
