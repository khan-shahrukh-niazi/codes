#include <iostream>
#include <fstream>
using namespace std;
class Node {
private:
string id;
double rating;
int votes;
Node *next = NULL;
public:
void setid(string id){
        this->id = id;
}
void setvote(double votes){
        this->votes= votes;
}
void setrating(int rating){
        this->rating = rating;
}
void setnext(Node *next){
        this->next = next;
}
string getid(){
        return id;
}
double getrating(){
        return rating;
}
int getvotes(){
        return votes;
}
Node* getnext(){
        return next;
}

Node(string id, double rating, int votes){
        this->id = id;
        this->rating=rating;
        this->votes=votes;
        next = NULL;
}            // End of constructor
};          // End of Node class
class Linkedlist {

public:
Node *first=NULL;
Node* getfirst(){
        return first;
}
void addatstart(string id, double rating, int votes){
        Node *temp= new Node(id,rating,votes);
        if(first == NULL) {
                first = temp;
        } else{
                temp->setnext(first);
                first = temp;
        } // End of else statment
}         // End of addatstart function

void display(){
        Node *temp = first;

        if(temp==NULL) {
                cout << "No elements exist :" << endl;
        } // End of if statement
        else {
                while(temp!=NULL) {
                        cout << "Data of node  is " << temp->getid() << "\t" << temp->getrating() << "\t" << temp->getvotes() <<endl;
                        temp=temp->getnext();

                } //  End of while loop
        } // End of else statement
}         // End of display function

void displayrate(string id, double rate, int votes )
{
        cout << id <<"\t"<< rate <<"\t"<< votes <<endl;
}


};
class Hashtable :  public Linkedlist {
int key;
public:
Linkedlist table[300];

void file(){
        long counter=0;
        string id;
        double rating;
        int votes;
        ifstream shani;
        shani.open("khan.txt");
        while(shani.eof()==0) {

                shani >> id;
                shani >> rating;
                shani >> votes;
                //      cout << id <<"\t"<< rating <<"\t"<< votes <<endl;
                counter++;
                int rate=rating;
                key=Hashfun(rate);
                table[key].addatstart(id,rating,votes);
        }
        cout << "Number of movies are :" << counter <<endl;
        shani.close();
} // End of file
void search(double rating){
        int key =Hashfun(rating);
        searchdisplay(key,rating);

} // End of search function


void searchdisplay(int key, double rating){
        int counter = 0;
        Node* temp = table[key].first;
        while(temp!=NULL) {

                if(temp->getrating()==rating) {
                        table[key].displayrate(temp->getid(), temp->getrating(), temp->getvotes());
                        counter++;
                }
                temp = temp->getnext();
        }
        cout << "Number of movies are :" << counter <<endl;
}
int Hashfun(int data)
{
        int index;
        index=data%300;
        return index;
}      // End of hash function

};

int main(){

        Hashtable h;
        cout << "Hash is called :" << endl;
        h.file();
        h.search(2.5);

        return 0;
}
