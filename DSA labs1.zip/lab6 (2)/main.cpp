#include <iostream>
using namespace std;
class Queue
{
public:
    int arrays[10]= {0};
    int start=0,ends=0;
    void enque(int x)
    {
        if(ends==10)
        {
            cout<<" queue is full\n";
            return;
        }
        arrays[ends]=x;
        ends++;
    }
    void display()
    {
        for(int x=0; x<10; x++)
        {
            cout<<x<<"-->"<<arrays[x]<<endl;
        }
    }
    void Deque()
    {
      int fronts=start;
        for(int x=1; x<11; x++)
        {
            arrays[fronts]=arrays[fronts+1];
            fronts++;
        }
        ends--;
    }
    void peak()
    {
        cout<<"\n Peak value of queue is "<<arrays[start]<<endl;
    }
};
class Stack
{
public:
    int arrays[10]= {0};
    int start=0;
    void push(int x)
    {
        if(start==10)
        {
            cout<<"STACK is FULL\n";
            return;
        }
        arrays[start]=x;
        start++;
    }
    void pop()
    {
        arrays[start-1]=0;
        start--;
    }
    void show()
    {
        for(int x=0; x<=9; x++)
        {
            cout<<x<<"-->"<<arrays[x]<<endl;
        }
    }
    void peak()
    {
        cout<<"\n Peak value of STACK is "<<arrays[start-1]<<endl;

    }
};
void menu()
{
    Queue q;
        cout<<"you are queue sir\n";
    int x;
    char z;     while(z!='O'&& z!='o')
        {
           cout<<"\t\t\t\t press E or e to enqueue\n";
            cout<<"\t\t\t\t press D or d to dequeue\n";
            cout<<"\t\t\t\t press P or p for peak  \n";
            cout<<"\t\t\t\t press S or s to display\n";
            cin>>z;
            if(z=='E' || z=='e')
            {
                cout<<"enter number to enqueue sir\n";
                cin>>x;
                q.enque(x);
            }
            if(z=='D' || z=='d')
            {
                cout<<"dequeuing for you sir\n";
                q.Deque();
            }
            if(z=='P' || z=='p')
            {
                q.peak();
            }
            if(z=='S' || z=='s')
            {
                cout<<"showing Queue for you\n";
                q.display();
            }
        }
    }
void  menu1()
    {

    Stack s;
        cout<<"you are in stack sir\n";
        char z;
        int x;
        while(z!='O'&& z!='o')
        {
            cout<<"\t\t\t\t press E or e to PUSH    \n";
            cout<<"\t\t\t\t press D or d to POP     \n";
            cout<<"\t\t\t\t press P or p for peak   \n";
            cout<<"\t\t\t\t press W or w for exit   \n";
            cout<<"\t\t\t\t press S or s to display \n";
            cin>>z;
            if(z=='E' || z=='e')
            {
                cout<<"enter number to push sir\n";
                cin>>x;
                s.push(x);
            }
            if(z=='D' || z=='d')
            {
                cout<<"POPING for you sir\n";
                s.pop();
            }
            if(z=='P' || z=='p')
            {
                s.peak();
            }
            if(z=='S' || z=='s')
            {
                cout<<"showing STACK for you\n";
                s.show();
            }
        }
    }
int main()
{
    char choice;
    cout<<"want to implement the Queue( prees Q || q) OR for stack( press S || s)\n";
    cin>>choice;
    if(choice=='S' || choice=='s')
        menu1();
    if(choice=='Q' || choice=='q')
        menu();
    /*Stack s;
    s.push(1);
    s.push(2);
    s.push(3);
    s.push(4);
    s.push(5);
    s.push(6);
    s.push(7);
    s.push(8);
    s.pop();
    s.push(8);
    s.push(9);
    s.push(10);
    s.push(11);    //s.pop();
    s.dispaly();
    */return 0;
}
