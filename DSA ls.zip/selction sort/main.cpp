#include <iostream>

using namespace std;
class Sort
{
public:
    int c=0,n=0;
    void Movemin(int hello[],int x,int c)
    {
        int low=hello[c];
        int index;
        for(int i=c; i<x; i++)
        {
            if(hello[i]<low)
            {
                low=hello[i];
                index=i;
            }
        }

        hello[index]=hello[c];
        hello[c]=low;
    }


    void SelectionSort(int hello[],int x)
    {
        for(int i=0; i<x; i++)
        {
            Movemin(hello,x,i);

        }
        for(int i=0; i<5; i++)
            cout<<i<<"-->"<<hello[i]<<endl;
    }

};
int main()
{
    Sort s;
    int hello[5]= {100,999,848,77,66};
    s.SelectionSort(hello,5);
//    s.display();
    return 0;
}
