#include <iostream>

using namespace std;

class Hash
{
public:
    int hello[11]= {0};
    int k,j=0;
    int counter=0;
    int add (int key)
    {
        if(counter==11)
        {
            cout<<"hash table is full sir\n";
            return 0;
        }
        int x=Hashfunction(key);

        if(hello[x]==0)
        {
            hello[x]=key;
            counter++;
        }
        else
        {
            k=(x+j*j)%11;

            j++;
            while(hello[k]!=0)
            {

                k=(x+j*j)%11;
                j++;
            }
            hello[k]=key;
            j=0;
            counter++;
        }

    }
    int Hashfunction(int key)
    {
        return key%11;
    }
    void display()
    {
        for(int i=0; i<=10; i++)
            cout<<i<<"=="<<hello[i]<<endl;
    }

    int Delete(int key)
    {
        int x=Hashfunction(key);
        int j;
        if(hello[x]==0)
            cout<<"This value is not present here"<<endl;
        if(hello[x]==-1)
            x++;
        if(hello[x]==key)
        {
            hello[x]=-1;
            counter--;
        }
        else
        {

            j=1;
            while(hello[x]!=0 && j<11)
            {
                x=(Hashfunction(key)+(j*j))%11;
                if(hello[x]==key)
                {
                    hello[x]=-1;

                    counter--;
                    return 0;
                }
                j++;
            }

        }

                cout<<"no sir given data "<<key<<" is not present in hash table\n";

    }

    int Search(int key)
    {
        int x=Hashfunction(key);
        int j;
        if(hello[x]==key)
            cout<<"given data is present in hash table at "<<x<<" index"<<endl;
        return 0;
        if(hello[x]==0 || hello[x]==-1)
            cout<<"Given data "<<key<<" is not present in hash table"<<endl;
        if(hello[x]!=0)
        {
            j=1;
            while(hello[x]!=0 && j<11)
            {
                x=(Hashfunction(key)+(j*j))%11;
                if(hello[x]==0)
                {
                    cout<<"No data is present here"<<endl;
                    return 0;
                }
                if(hello[x]==key)
                {
                    cout<<"given data "<<key<<" is present in hash table at "<<x<<" index"<<endl;
                    return 0;
                }
                j++;
            }

        }
        cout<<"no sir given data "<<key<<" is not present in hash table\n";
    }
};
int main()
{
    Hash h;
    h.add(12);
    h.add(23);
    h.add(34);
    h.add(234);
    h.add(3405);
    h.add(1901);
    h.add(4321);
    h.add(2345);
    h.add(5432);
    h.add(4432);
    h.add(252);
    h.Delete(34085);
   // h.Search(3405);
    h.display();
}
