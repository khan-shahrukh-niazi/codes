#include <iostream>
using namespace std;
class node
{
private:
    int data;
    node *next;
    node *prev;
public:

    node(int x)
    {
        data=x;
        next=NULL;
        prev=NULL;
    }
    void setdata(int x)
    {
        data=x;
    }
    int getdata()
    {
        return data;
    }
    void setnext(node *x)
    {
        next=x;
    }
    node* getnext()
    {
        return next;
    }
    void setprev(node *x)
    {
        prev=x;
    }
    node* getprev()
    {
        return prev;
    }
};
class linklist
{
public:
    node *first;
    node *hello=NULL;
    linklist()
    {
        first=NULL;
    }
    void addatstart(int x)
    {
        node *new1=new node(x);

        if(first==NULL)
        {
            first=new1;
            new1->setprev(NULL);
            hello=new1;
            return;
        }
        new1->setnext(first);
        first->setprev(new1);
        first=new1;
        first->setprev(NULL);
    }
    void display()
    {
        int x=1;
        node *temp=first;
        while(temp!=NULL)
        {
            cout<<x<<"->"<<temp->getdata()<<endl;
            temp=temp->getnext();
            x++;
        }
    }
    void removefromend()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from end of list \n";
            return;
        }
        hello=hello->getprev();
      if(hello==NULL){first=NULL;return;}
        hello->setnext(NULL);
    }
};
class que{
public:
    linklist l;
    void enqueue(int x)
    {
        l.addatstart(x);
    }
    void display()
    {
        l.display();
    }
    void dequeue()
    {
        l.removefromend();
    }
};
int main()
{
    que q;
    q.enqueue(123);
    q.enqueue(122);
    q.enqueue(121);
    q.enqueue(120);
    q.enqueue(119);
    q.dequeue();
    //q.dequeue();
    //q.dequeue();
    //q.dequeue();
//    q.dequeue();
    //q.enqueue(12345);
    //q.dequeue();
    q.display();
}
