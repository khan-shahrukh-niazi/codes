#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *left,*right;
    node(int x)
    {
        data=x;
        left=NULL;
        right=NULL;
    }
};
class tree
{
public:
    node *root;
    tree()
    {
        root=NULL;
    }
    void add(int x)
    {
        node  *new1=new node(x );
        node *temp=root;
        if (root==NULL)
        {
            root=new1;
            return;
        }
        while(true)
        {
            if(temp->data>x)
            {
                if(temp->left==NULL)
                {
                    temp->left=new1;
                    return;
                }
                temp=temp->left;
            }
            if(temp->data<x)
            {
                if(temp->right==NULL)
                {
                    temp->right=new1;
                    return;
                }
                temp=temp->right;
            }
        }
    }
    void Search(int x)
    {
        node *temp=root;
         if(root==NULL)
        {
            cout<<"Tree is empty\n";
            return;
        }
        while(true)
        {
            if(temp->data==x)
            {
                cout<<"value is present in Tree\n";
                return;
            }
            if(temp->data>x)
            {
                if(temp->left==NULL)
                {
                    cout<<"not present \n";
                    return;
                }
                temp=temp->left;
            }
            if(temp->data<x)
            {
                if(temp->right==NULL)
                {
                    cout<<"not present \n";
                    return;
                }
                temp=temp->right;
            }
        }
    }
    void show1(node *start)
    {
        if(start==NULL)
            return;
        show1(start->left);
        cout<<start->data<<endl;

        show1(start->right);
    }
    void show2(node *start)
    {
        if(start==NULL)
            return;
        cout<<start->data<<endl;
        show2(start->left);
        show2(start->right);
    }
    void show3(node *start)
    {
        if(start==NULL)
            return;
        show3(start->left);
        show3(start->right);
        cout<<start->data<<endl;
    }
    node* low(node* start)
    {
        while(start->left != NULL)
            start=start->left;
        return start;
    }
    node*  deletes( node *start,int value)
    {
        if(start==NULL)
            return start;
        else if(value <  start->data)
            start->left=deletes(start->left,value);
        else if(value  > start->data)
            start->right=deletes(start->right,value);
        else
        {
            if(start->left==NULL && start->right==NULL)
            {
                start=NULL;
                return start;
            }
            else if(start->left==NULL)
            {
                start=start->right;
                return start;
            }
            else if(start->right==NULL)
            {
                start=start->left;
                return start;
            }
            else
            {
                node *temp=low(start->right);
                start->data=temp->data;
                start->right=deletes(start->right,temp->data);
            }
        }
    }
    void display()
    {
        cout<<"\n INORDER\n\n";
        show1(root);
        cout<<"\n PREORDER\n\n";
        show2(root);
        cout<<"\n POSTORDER\n\n";
        show3(root);
    }
    void rem(int value)
    {
        deletes(root,value);
    }
};
int main()
{
    tree t;
    t.add(12);
    t.add(44);
    t.add(55);
    t.add(120);
    t.add(333);
    t.add(1);
    t.add(110);
    t.add(108);
    t.add(115);
    t.rem(12);
    t.display();
    return 0;
}
