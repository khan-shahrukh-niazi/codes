#include <iostream>

using namespace std;
class Queue
{
public:
    int arrays[5]= {0};
    int  start= -1, last = -1, n=5;

    void enqueue(int val)
    {
        if ((start == 0  &&  last == n-1) || (start == last+1))
        {
            cout<<"Queue  full or empty \n";
            return;
        }
        if (start == -1)
        {
            start = 0;
            last= 0;
        }
        else
        {
            if (last == n - 1) //if array is full and first entries are empty of list then end become first index of array
                last = 0;
            else
                last++;
        }
        arrays[last] = val ;
    }
    void dequeu()
    {
        if (start == -1)
        {
            cout<<"Queue  is empty\n";
            return ;
        }
        if (start == last)
        {
            start = -1;
            last = -1;
        }
        else
        {
            if (start == n - 1)
            {
                arrays[start]=0;
                start = 0;
            }
            else
                arrays[start]=0;
            start = start + 1;
        }
    }
    void display()
    {
        for (int x=0; x<5; x++)
        {
            cout<<arrays[x]<<endl;
        }
    }
};
int main()
{
    Queue q;
    q.enqueue(12);
    q.enqueue(13);
    q.enqueue(14);
    q.enqueue(15);
    q.enqueue(16);
    q.display();
    cout<<endl;
    q.dequeu();
    q.dequeu();
    //q.display();
    //q.enqueue(11);
    //q.dequeu();
    //q.enqueue(10);
    q.enqueue(111);
    //q.dequeu();
    //q.dequeu();
    //q.enqueue(1212);
    q.display();
    return 0;
}
