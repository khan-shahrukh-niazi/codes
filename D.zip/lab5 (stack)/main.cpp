                                                                //stack in linklist
#include <iostream>
#include <fstream>
using namespace std;
class node
{
private:
    int data;
    node *next;
    node *prev;
public:

    node(int x)
    {
        data=x;
        next=NULL;
        prev=NULL;
    }
    void setdata(int x)
    {
        data=x;
    }
    int getdata()
    {
        return data;
    }
    void setnext(node *x)
    {
        next=x;
    }
    node* getnext()
    {
        return next;
    }
    void setprev(node *x)
    {
        prev=x;
    }
    node* getprev()
    {
        return prev;
    }
};
class linklist
{
public:
    node *first;
    linklist()
    {
        first=NULL;
    }
    void addatstart(int x)
    {
        node *new1=new node(x);

        if(first==NULL)
        {
            first=new1;
            new1->setprev(NULL);
            return;
        }
        new1->setnext(first);
        first->setprev(new1);
        first=new1;
        first->setprev(NULL);
    }
    void display()
    {
        int x=1;
        node *temp=first;
        while(temp!=NULL)
        {
            cout<<x<<"->"<<temp->getdata()<<endl;
            temp=temp->getnext();
            x++;
        }
    }
    void addatend(int x)
    {
        node *new1=new node(x);

        if(first==NULL)
        {
            first=new1;
            return;
        }
        node *temp=first;
        while(temp->getnext()!=NULL)
        {
            temp=temp->getnext();
        }

        temp->setnext(new1);
        new1->setprev(temp);
    }
    void removefromstart()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from start of list \n";
            return;
        }
        if(first->getnext()==NULL)
        {
            first=NULL;
            return;
        }
        first=first->getnext();
        first->setprev(NULL);
    }
    void removefromend()
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not remove node from end of list \n";
            return;
        }
        if(first->getnext()==NULL)
        {
            first=NULL;
            return;
        }
        node *temp=first;
        while(temp->getnext()->getnext()!=NULL)
        {
            temp=temp->getnext();
        }
        temp->setnext(NULL);
    }
    void Remove(int value)
    {
        if(first==NULL)
        {
            cout<<" list is empty so we can not perform given task on list \n";
            return;
        }
        if(first->getdata()==value)
        {
            removefromstart();
            return;
        }
        node *temp=first;
        while(temp->getnext()!=NULL)
        {
            if(temp->getnext()->getdata()==value)
            {
                node *free=temp;
                temp->setnext(temp->getnext()->getnext());
                temp->setprev(free);
                break;
            }
            temp=temp->getnext();
            if(temp==NULL)
            {
                break;
            }
        }

    }
    int listlength()
    {
        int x=0;
        node *temp=first;
        while(temp!=NULL)
        {
            temp=temp->getnext();
            x++;
        }
        return x;
    }
    void removeAt(int index)
    {
        if(first==NULL)
        {
            cout<<" LIST is EMPTY \n";
            return;
        }
        if(index > listlength())
        {
            cout<<" given index ("<<index<<") is not present in list \n";
            display();
            return;
        }
        if(index==0)
        {
            cout<<"list start from 1 NOT 0 so reenter the index sir:\n";
            return;
        }

        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {

            if(index==1)
            {
                removefromstart();
                break;
            }
            y++;

            if(index==y)
            {

                node *free=temp;
                temp->setnext(temp->getnext()->getnext());
                temp->setprev(free);
                break;
            }
            temp=temp->getnext();


        }


    }
    void  addAt(int index,int value)
    {
        if(first==NULL)
        {
            cout<<"list is empty\n";
            return;
        }
        if(index==0 ||index==1)
        {
            addatstart(value);
            return;
        }
        if(index >listlength())
        {
            addatend(value);
            return;
        }
        node *temp=first;

        int y=1;
        while(temp!=NULL)
        {
            if(y==index-1)
            {
                node *new1=new node(value);
                new1->setnext(temp->getnext());
                temp->getnext()->setprev(new1);
                temp->setnext(new1);
                new1->setprev(temp);
                break;
            }

            temp=temp->getnext();
            y++;
        }
    }
    int getat(int index)
    {
        if(index==0)
        {
            index=1;
        }
        if(first==NULL)
        {
            return -1;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(index==y)
            {
                return temp->getdata();
            }
            temp=temp->getnext();
            y++;
        }
        return -1;
    }
    int Find(int value)
    {
        if(first==NULL)
        {
            cout<<"list is empty \n";
            return -1;
        }
        node *temp=first;
        int y=1;
        while(temp!=NULL)
        {
            if(temp->getdata()==value)
            {
                return y;
            }
            temp=temp->getnext();
            y++;
        }
        return -1;
    }
    void oye()
    {
        if(first==NULL)
        {
            cout<<"program is complete right";
        }
        else
        {
                        cout<<"program is not right";

        }
    }
};
class Stack{
public:
    linklist l;
void push(int x)
{
    l.addatstart(x);
}
void pop()
{
    l.removefromstart();
}
void display()
{
    l.display();
}
void peak()
{
    cout<<"\n peak of stack is "<<l.getat(1);
}
void Back()
{
    int x=l.listlength();
    cout<<"\n back of stack is "<<l.getat(x);
}
void Find(int x)
{
          cout<<"\n given value ("<<x<<") index is " <<l.Find(x);

}
void completecheckkaro()
{
    l.oye();
}
};
int main()
{

    Stack s;
    s.push(5);
    s.push(4);
    s.push(3);
    s.push(2);
    s.push(1);
    s.push(0);
    s.display();
     s.peak();
     s.Back();
     s.Find(3);
    //s.pop();
    //s.pop();
    //s.pop();
return 0;
}
